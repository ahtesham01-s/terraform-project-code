Deploy CSI DRIVER, the CSI driver is used to managed EFS drive on EKS cluster
1. apply the csi.yaml
2. apply csi controller deployment.yaml
3. apply csi node daemonset.yaml
