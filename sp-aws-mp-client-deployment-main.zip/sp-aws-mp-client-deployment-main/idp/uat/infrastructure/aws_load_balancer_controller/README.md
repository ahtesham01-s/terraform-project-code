Deploy the AWS Controller Load balancer

https://docs.aws.amazon.com/eks/latest/userguide/aws-load-balancer-controller.html

1. Create an IAM policy
```
 aws iam create-policy \
    --policy-name AWSLoadBalancerControllerIAMPolicy \
    --policy-document file://iam_policy.json
```

2. Create an IAM role. Create a Kubernetes service account named aws-load-balancer-controller in the kube-system namespace for the AWS Load Balancer Controller and annotate the Kubernetes service account with the name of the IAM role.
```
eksctl create iamserviceaccount \
  --cluster=sp-aws-mp-eu-idp-uat-eks-cluster \
  --namespace=kube-system \
  --name=aws-load-balancer-controller \
  --role-name AmazonEKSLoadBalancerControllerRole \
  --attach-policy-arn=arn:aws:iam::168616777926:policy/AWSLoadBalancerControllerIAMPolicy \
  --approve
```

3. login to ECR
```
aws ecr get-login-password --region eu-central-1  | helm registry login --username AWS --password-stdin 931371049134.dkr.ecr.eu-central-1.amazonaws.com
```

4. pull the helm chart from your local s3 bucket


5. helm install
```
helm install aws-load-balancer-controller aws-load-balancer-controller-1.6.2.tgz \
  -n kube-system \
  --set clusterName=sp-aws-mp-eu-idp-uat-eks-cluster \
  --set serviceAccount.create=false \
  --set serviceAccount.name=aws-load-balancer-controller \
  --set image.repository=931371049134.dkr.ecr.eu-central-1.amazonaws.com/aws-load-balancer-controller
```

6. Verify that the controller is installed.
```
kubectl get deployment -n kube-system aws-load-balancer-controller
```