# sp-aws-mp-client-deployment
Client environment deployment configurattion
