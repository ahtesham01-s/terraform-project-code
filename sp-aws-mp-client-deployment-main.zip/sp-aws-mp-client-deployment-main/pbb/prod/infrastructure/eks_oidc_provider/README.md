Creating an IAM OIDC provider for your cluster

1. Determine the OIDC issuer ID for your cluster.
```
cluster_name=sp-aws-mp-eu-pbb-prod-eks-cluster
```

```
oidc_id=$(aws eks describe-cluster --name $cluster_name --query "cluster.identity.oidc.issuer" --output text | cut -d '/' -f 5)
```

```
echo $oidc_id
```

2. Determine whether an IAM OIDC provider with your cluster's issuer ID is already in your account.
```
aws iam list-open-id-connect-providers | grep $oidc_id | cut -d "/" -f4
```

3. Create an IAM OIDC identity provider for your cluster with the following command.
```
eksctl utils associate-iam-oidc-provider --cluster $cluster_name --approve
```