Apply each file from the eks adminhost
This will create the storage class for each EFS drive previously created from terraform
```
kubectl apply -f <folder_with_storageClasse.yaml>
```

```
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: efs-avaloq
parameters:
  directoryPerms: "777"
  fileSystemId: fs-011b1be833b454d01 # EFS drive Id from AWS console/Terraform output
  provisioningMode: efs-ap
provisioner: efs.csi.aws.com
reclaimPolicy: Delete
volumeBindingMode: Immediate
```
