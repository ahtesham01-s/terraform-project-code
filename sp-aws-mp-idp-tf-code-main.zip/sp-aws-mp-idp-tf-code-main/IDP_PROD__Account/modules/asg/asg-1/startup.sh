#!/bin/bash
sudo mkdir /download
sudo cd /
sudo mount -t nfs4 fs-0b3a0dc90d0e457f2.efs.eu-central-1.amazonaws.com:/ download