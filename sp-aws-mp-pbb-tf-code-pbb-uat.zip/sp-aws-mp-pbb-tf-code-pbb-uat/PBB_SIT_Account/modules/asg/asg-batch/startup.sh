#!/bin/sh
/root/tomcat/bin/startup.sh
/root/ActiveMQ/apache-activemq-5.18.1/bin/activemq start
sudo echo "10.1.53.190 fs-05a5fafbd67b0b9f9.efs.eu-central-1.amazonaws.com" >> /etc/hosts
sudo echo "10.1.55.141 fs-05a5fafbd67b0b9f9.efs.eu-central-1.amazonaws.com" >> /etc/hosts
sudo mount -t nfs4 fs-05a5fafbd67b0b9f9.efs.eu-central-1.amazonaws.com: /efs