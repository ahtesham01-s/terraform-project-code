#!/bin/sh
/root/tomcat/bin/startup.sh
/root/ActiveMQ/apache-activemq-5.18.1/bin/activemq start