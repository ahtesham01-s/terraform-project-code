#!/bin/sh
/root/tomcat/bin/startup.sh
/root/ActiveMQ/apache-activemq-5.18.1/bin/activemq start
sudo echo "10.1.69.117 fs-06e68b449078af42b.efs.eu-central-1.amazonaws.com" >> /etc/hosts
sudo echo "10.1.71.111 fs-06e68b449078af42b.efs.eu-central-1.amazonaws.com" >> /etc/hosts
sudo mount -t nfs4 fs-06e68b449078af42b.efs.eu-central-1.amazonaws.com: /efs