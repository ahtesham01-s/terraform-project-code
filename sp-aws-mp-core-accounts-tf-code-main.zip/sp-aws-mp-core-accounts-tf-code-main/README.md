# sp-aws-mp-core-accounts-tf-code
This repo will contain TF source code for Synpulse core account configuration 
